float *conj_grad(float *A, float *b, float *x0, int n);
